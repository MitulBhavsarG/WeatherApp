import React, { useEffect, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import axios from 'axios'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const options = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top',
    },
    title: {
      display: true,
      text: 'Vivsoft',
    },
  },
};

export function WeatherCharts() {
  const [forecasts, setForecasts] = useState([])

  useEffect(async () => {
    await fetchForcast()
    setInterval(fetchForcast, 5000);
  }, [])

  const fetchForcast = async () => {
    try {
      // endpoint comes from .env
      const res = await axios.get('http://localhost:3000/')
      setForecasts(res.data.data)
    } catch (err) {
      console.error(err)
    }
  }

  const getLabels = () => {
    const l =  ['Current',];
    if (forecasts && forecasts.forecast) {
      forecasts.forecast.map(f => {
        const d = new Date(f.time)
        l.push(d.toTimeString().substring(0, 5))
      })
    }
    return l
  }

  const getData = () => {
    const forcastData = []

    if (forecasts && forecasts.forecast) {
      forcastData.push(forecasts.current.temp_f)
  
      if (forecasts && forecasts.forecast) forecasts.forecast.map(f => {
        forcastData.push(f.temp_f)
      })
    }
    return forcastData
  }

  const labels = getLabels();
  const forcastData = getData()

  const data = {
    labels,
    datasets: [
      {
        label: 'Temperature',
        data: forcastData,
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
      },
    ],
  };
  return forcastData.length > 0 ? <Line options={options} data={data} /> : <>Loading...</>;
}
