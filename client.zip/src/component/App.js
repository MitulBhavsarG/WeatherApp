import React from "react";
import { WeatherCharts } from "./charts";

export const App = () => {
  return <div className="ui container"><WeatherCharts /></div>;
};

export default App;
