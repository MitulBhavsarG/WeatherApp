const axios = require('axios')
var cors = require('cors')
const express = require('express')
const app = express()
app.use(cors())

const getForcastData = async () => {
  // URL endpoint will come from .env
  const forecastData = await axios.get('https://api.weatherapi.com/v1/forecast.json?key=3738897fde7047f0a1822737203011&q=20171&days=1')
  const forecasts = forecastData.data

  const current = {
    temp_f: forecasts.current.temp_f
  }

  const forecast = forecasts.forecast.forecastday.map((f) => {
    return f.hour.map(h => {
      console.log(h)
      return { time: h.time, temp_f: h.temp_f }
    })
  })[0]

  return {
    current,
    forecast: forecast
  }
}

app.get('/', async function (req, res) {
  const forcasts = await getForcastData()
  const ret = {
    data: forcasts,
    status: 'success'
  }
  res.send(ret)
})

app.listen(3000)